// ElizabethItemClassBlackBox.cpp : main project file.

#include "stdafx.h"
#include "item.h"

using namespace System;

int main(array<System::String ^> ^args)
{
	/****** WHEN THIS BUILDS WITHOUT ERROR SEND IT BACK TO BE TESTED *******/



    Console::WriteLine(L"Hello World");
    return 0;
}
